# Viber bot logic
